#'
#'
#' @export
vantagens_pacote<-function(){
  resposta<-"As vantagens de se organizar um código em pacotes são a relação entre
              funcionalidades parecida presentes em um único elemento
              ,tabém casos tenhamos um conjunto de funções, dados, que usamos
              com frequeencia , organiza-los em um pacote torna a utilização
              mais rápida , segura e limpa. Devemos utilizar pacotes para organizar
              os códigos nos casos em que :
              -Com frequencia fazemos uso deum conjunto ;
              de funcionalidades;
              -Caso desejamos sintetizar em um único elemento
              multiplas funcionalides relacionadas, não apenas no sentido computacional
              mas de ideias;
              -Distribuição e divulgação de um conjunto de códigos
              que podem ajudar outros na resolução de problemas particulares.
              "
print(resposta)
}
